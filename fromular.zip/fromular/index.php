﻿<?php
// přihlašovací údaje do DB
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["submit"])){

    $pohlavi = $_GET["pohlavi"];
    $jmeno = $_GET["jmeno"];
    $prijmeni = $_GET["prijmeni"];
    $email = $_GET["email"];
    $otazka = $_GET["otazka"];

     $sql = "INSERT INTO tabulka (pohlavi, jmeno, prijmeni, email, otazka)  VALUES ('$pohlavi', '$jmeno','$prijmeni','$email','$otazka')";
    if ($conn->query($sql) === TRUE) {
        echo "Vase udaje se odeslaly<br>";
    } 
    else {
        echo "Chyba: " . $sql . "<br>" . $conn->error;
    }


}

?>
<html>
    <body>
        <form action="" method="get">
            <label for="pohlavi">Pohlavi:</label>
            <select name="pohlavi" id="pohlavi">
            <option value="muz">Muz</option>
            <option value="zena">Zena</option>
            <option value="nic">Nic</option>
            </select>
            <br>
            
            <label for="jmeno">Jmeno:</label><br>
            <input type="text" id="jmeno" name="jmeno"><br>
            
            <label for="prijmeni">Prijmeni:</label><br>
            <input type="text" id="prijmeni" name="prijmeni"><br>

            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email"><br>
            
            <label for="ano">ano</label>
            <input type="radio" id="otazka" name="otazka">
            <label for="ne">ne</label>
            <input type="radio" id="otazka" name="otazka">
            <br>

            <input name="submit" type="submit" value="Submit">
</body>
</html>
